<?php
include("connection.php");

$query=isset($_GET['id'])? "SELECT * FROM `ethical_hacking` WHERE id ='{$_GET['id']}'": "SELECT * FROM `ethical_hacking`";

$result=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($result)>0){
    $data=array();
    while($row=mysqli_fetch_assoc($result)){
        $data[]=$row;
    }
    echo json_encode([
        'success'=> 1,
        'output'=>$data,
    ]);
}

else{
    echo json_encode([
        'success'=>0,
        'message'=>'No Record Found ..!',
    ]);
}

?>