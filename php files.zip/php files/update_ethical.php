<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: PUT");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

    if ($_SERVER['REQUEST_METHOD'] == "OPTIONS")
        die();
    
    if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
        http_response_code(405);
        echo json_encode([
            'success' => 0,
            'message' => 'Bad Request detected! Only PUT method is allowed',
        ]);
        exit;
    }

    require 'connection.php';
// To receive JSON string we can use the “php://input” along with the function   file_get_contents() which helps us receive JSON data as a file and read it into a string. Later, we can use the json_decode() function to decode the JSON string.
    $data = json_decode(file_get_contents("php://input"));

    if (!isset($data->id)) {
        echo json_encode([
            'success' => 0, 
            'message' => 'Please enter correct contact id.']);
        exit;
    }

    $query = "SELECT * FROM ethical_hacking WHERE id={$data->id}";
    $result = mysqli_query($con, $query);
    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);
        $name = isset($data->name)? $data->name: $row['name'];
        $email = isset($data->email)? $data->email: $row['email'];
        $password = isset($data->password)? $data->password: $row['password'];
        $grade = isset($data->grade)? $data->grade: $row['grade'];
        $fees = isset($data->fees)? $data->fees: $row['fees'];
        

        $name = htmlspecialchars(strip_tags($name));
        $email = htmlspecialchars(strip_tags($email));
        $password = htmlspecialchars(strip_tags($password));
        $grade = htmlspecialchars(strip_tags($grade));
        $fees = htmlspecialchars(strip_tags($fees));
        
        $query_update= "UPDATE `ethical_hacking` SET `name`='$name',`email`='$email',`password`='$password',
        `grade`='$grade',`fees`='$fees' WHERE id={$data->id}";

        mysqli_query($con, $query_update);
        if(mysqli_affected_rows($con) > 0){
            echo json_encode([
                'success' => 1,
                'message' => 'Record updated successfully'
            ]);
            exit;
        }

        echo json_encode([
            'success' => 0,
            'message' => 'Did not udpate. Something went  wrong.'
        ]);
        exit;
    }
    else{
        echo json_encode([
            'success' => 0, 
            'message' => 'Invalid ID. No record found by the ID.']);
        exit;
    }
 ?>
