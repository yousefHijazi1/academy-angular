<?php
    header("Access-Control-Allow-Origin: *"); // to make the API public to anyone to access
    header("Access-Control-Allow-Methods: POST");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

    // return only the headers and not the content
    if ($_SERVER['REQUEST_METHOD'] == "OPTIONS")
        die();
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST'){
        http_response_code(405);
        echo json_encode([
            'success' => 0,
            'message' => 'Bad Request!.Only POST method is allowed',
        ]);
        exit;
    }
    require 'connection.php';
    $data = json_decode(file_get_contents("php://input"));
    if (!isset($data->name) || !isset($data->password)|| !isset($data->gender) ||!isset($data->fees) || !isset($data->email)){
        echo json_encode([
            'success' => 0,
            'message' => 'All fields are required',
        ]);
        exit;
    }
    elseif (empty(trim($data->name)) || empty($data->password)|| empty($data->gender) || empty(trim($data->email))){
        echo json_encode([
            'success' => 0,
            'message' => 'Field cannot be empty. Please fill all the fields.',
        ]);
        exit;
    }
    $name = htmlspecialchars(trim($data->name));
    $email = htmlspecialchars(trim($data->email));
    $password = htmlspecialchars(trim($data->password));
    $gender = htmlspecialchars(trim($data->gender));
    $fees = htmlspecialchars(trim($data->fees));
    
    
    $query = "INSERT INTO `ethical_hacking`( `name`, `email`, `password`, `gender`, `fees`) 
    VALUES ('$name','$email','$password','$gender','$fees')";
    
    mysqli_query($con, $query);

    if(mysqli_affected_rows($con)>0){
        http_response_code(201);
        echo json_encode([
            'success' => 1,
            'message' => 'Data Inserted Successfully.'
        ]);
        exit;
    }
    echo json_encode([
        'success' => 0,
        'message' => 'There is a problem in data inserting'
    ]);
    exit;
?>
