<?php
include("connection.php");

$postdata= file_get_contents("php://input");
if(isset($postdata) && !empty($postdata))
{
    $request = json_decode($postdata);
    $email = trim($request -> EMAIL);
    $password = trim($request -> PASSWORD);

    $sql = "select * from users where Email ='$email' and Password = '$password' ";
    $result=mysqli_query($con,$sql) or die(mysqli_error($con)) ;

    if(mysqli_num_rows($result)>0){
        $data = array('message' => 'success');
        echo json_encode($data);
    }
    else{
        $data = array('message' => 'failed');
        echo json_encode($data);
    }
}

?>